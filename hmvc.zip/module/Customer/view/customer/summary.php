<?php

$dataPoints = array(
    array("y" => 7, "label" => "March"),
    array("y" => 12, "label" => "April"),
    array("y" => 28, "label" => "May"),
    array("y" => 18, "label" => "June"),
    array("y" => 41, "label" => "July")
);

?>

<script>
    window.onload = function() {

        var chart = new CanvasJS.Chart("chartContainer", {
            animationEnabled: true,
            title: {
                text: "Revenue Chart of Acme Corporation"
            },
            axisY: {
                title: "Revenue (in USD)",
                prefix: "$",
                suffix: "k"
            },
            data: [{
                type: "bar",
                yValueFormatString: "$#,##0K",
                indexLabel: "{y}",
                indexLabelPlacement: "inside",
                indexLabelFontWeight: "bold",
                indexLabelFontColor: "white",
                dataPoints: <?php echo json_encode($dataPoints, JSON_NUMERIC_CHECK); ?>
            }]
        });
        chart.render();

    }
</script>

<div id="chartContainer" style="height: 50vh; width: 100%;"></div>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>